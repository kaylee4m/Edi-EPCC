import input_helper
import numpy as np
from collections import defaultdict
from decimal import Decimal


### Precision ###

def Precision(TP,ret_doc):
    if ret_doc == 0:
        return 0
    return float(TP)/float(ret_doc)


### Recall ###

def Recall(TP,rel_doc):
    if rel_doc == 0:
        return 0
    return float(TP)/float(rel_doc)


### r-precision ###

# The first step is to get precision and recall values accroding fileID, queryID and rank
def calculate_helper(fileID,rank,queryID):
    qrels = input_helper.qrels_input()
    results = input_helper.file_input('S'+str(fileID)+'.results')
    Precisions = []
    Recalls = [] 
    rel_doc = [item[0] for item in qrels[queryID][1:]] # Receive relevent document
    ret_doc = [item[1] for item in results[queryID][0:rank]] # Receive retrieved document 
    TP = set(rel_doc) & set(ret_doc) 
    preci = Precision(len(TP),len(ret_doc))
    recall = Recall(len(TP),len(rel_doc))
    return preci,recall

# Then calculate the r-precision
def r_precision(fileID):
    qrels = input_helper.qrels_input()
    r_precision = []
    r_precisionlist = []
    for i,item in enumerate(qrels):
        r_precisionlist.append(calculate_helper(fileID,len(item)-1,i)[0])
    return r_precisionlist


### AP ###

def AP(fileID,queryID):
    qrels = input_helper.qrels_input()
    results = input_helper.file_input('S'+str(fileID)+'.results')
    Precisions = []
    rel_doc = [item[0] for item in qrels[queryID][1:]]
    retID = [item[1] for item in results[queryID]]
    index_of_rank = [i for i, r in enumerate(retID) if r in rel_doc]
    for i,index in enumerate(index_of_rank):
        preci = float(i+1)/(index+1)
        Precisions.append(preci)
    if Precisions == []:
        return 0
    else:
        return sum(Precisions)/len(rel_doc)

# Calculate MAP according AP
def MAP(fileID):
    APlist = []
    for i in range(0,10):
        APlist.append(AP(fileID,i))
    return sum(APlist)/len(APlist)


### nDCG ###

#Calculate DG
def DG(index,value):
    if index == 1:
        return value
    else:
        return float(value)/(np.log2(index))

#Calculate DCG
def DCG(fileID,queryID,rank):
    qrels = input_helper.qrels_input()
    results = input_helper.file_input('S'+str(fileID)+'.results') 
    DCG = 0.0
    rel_doc = [item[0] for item in qrels[queryID][1:]]
    IR_values = [item[1] for item in qrels[queryID][1:]]
    retID = [item[1] for item in results[queryID]]
    for i,r in enumerate(retID):
        if i >= rank:
            break
        if r in rel_doc:
            DCG += float(DG(i+1,IR_values[rel_doc.index(r)]))
    return(DCG)

#Calculate iDCG
def iDCG(fileID,queryID,rank):
    qrels = input_helper.qrels_input()
    iDCG = 0.0
    ivalues = sorted([item[1] for item in qrels[queryID][1:]],reverse=True)
    for i,item in enumerate(ivalues):
        if i >= rank:
            break
        iDCG += DG(i+1,int(item))
    return iDCG

# nDCG = DCG/iDCG
def nDCG(fileID,queryID,rank):
    return DCG(fileID,queryID,rank)/iDCG(fileID,queryID,rank)


### Output ###

def outputfiles():
    means_all = defaultdict(list)
    for i in range(1,7):
        means = defaultdict(list)
        file = open('systems/S'+str(i)+'.eval','w+')
        file.write('\t'+ 'P@10\t' + 'R@50\t' + "r-Precision\t" + 'AP\t' + 'nDCG@10\t' + 'nDCG@20\n')
        for j in range(0,10):           
            p10 = format(calculate_helper(i,10,j)[0],'.3f')
            means['p10'].append(float(p10))
            r50 = format(calculate_helper(i,50,j)[1],'.3f')
            means['r50'].append(float(r50))
            RP = format(r_precision(i)[j],'.3f')
            means['RP'].append(float(RP))
            ap = format(AP(i,j),'.3f')
            means['ap'].append(float(ap))
            nDCG10 = format(nDCG(i,j,10),'.3f')
            means['nDCG10'].append(float(nDCG10))
            nDCG20 = format(nDCG(i,j,20),'.3f')
            means['nDCG20'].append(float(nDCG20))
            file.write(str(j+1)+'\t'+p10+'\t'+r50+'\t'+ RP+'\t'+ ap +'\t'+nDCG10 + '\t'+nDCG20)
            file.write('\n')
        p10_m = format(sum(means['p10'])/len(means['p10']),'.3f')
        r50_m = format(sum(means['r50'])/len(means['r50']),'.3f')
        r_pre_m = format(sum(means['RP'])/len(means['RP']),'.3f')
        ap_m = format(sum(means['ap'])/len(means['ap']),'.3f')
        nDCG10_m = format(sum(means['nDCG10'])/len(means['nDCG10']),'.3f')
        nDCG20_m = format(sum(means['nDCG20'])/len(means['nDCG20']),'.3f')

        means_all[i] = [p10_m,r50_m,r_pre_m,ap_m,nDCG10_m,nDCG20_m]
        file.write('mean\t'+p10_m+'\t'+r50_m+'\t'+ r_pre_m+'\t'+ ap_m +'\t'+nDCG10_m + '\t'+nDCG20_m)
    file_all = open('systems/ALL.eval','w+')
    file_all.write('\t'+ 'P@10\t' + 'R@50\t' + "r-Precision\t" + 'AP\t' + 'nDCG@10\t' + 'nDCG@20\n')
    for no in range(1,7):
        file_all.write('S'+str(no)+'\t'+means_all[no][0]+'\t'+means_all[no][1]+'\t'+means_all[no][2]+'\t'+means_all[no][3]+'\t'+means_all[no][4]+'\t'+means_all[no][5]+'\n')
outputfiles()

