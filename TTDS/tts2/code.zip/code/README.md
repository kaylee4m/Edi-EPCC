
# Files
There are two python files and a systems folder which includes 6 results files from S1 to S6, and a qrels.txt.

One of the python file is 'input_helper.py' which is used to input results and qrels.

The other python file is 'EVAL.py' which is main module to calculate the six IR Evaluation measures.

# How to run
To run the module, run the module in the commend line:
  $ python EVAL.py

# Output
The output is in the path of /system/. It should includes 7 files. 6 of them are the evaluation result of the 6 different systems, the names are S1.eval to S6.eval. Besides, there is a "ALL.eval" which contains the average scores of each of the 6 systems.
